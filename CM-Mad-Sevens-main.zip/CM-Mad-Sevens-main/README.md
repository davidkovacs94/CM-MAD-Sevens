# CM-Mad-Sevens
A repository for Group 4 of Cognitive Modelling: Complex Behaviour for 2020-2021; a Swift and ACT-R implementation of the game "Sevens".  
