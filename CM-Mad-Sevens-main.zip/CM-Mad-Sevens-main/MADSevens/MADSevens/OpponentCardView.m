//
//  OpponentCardView.m
//  MADSevens
//
//  Created by D.L. Kovacs on 18/03/2021.
//

#import "OpponentCardView.h"

@implementation OpponentCardView

@end
